"use client";

import { motion } from "motion/react";

import Image from "next/image";

import { Mail } from "lucide-react";

import { useRouter } from "next/navigation";

export default function Auth() {
  const router = useRouter();

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: -30, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, type: "spring" }}
        className="flex flex-col items-center mb-16 relative z-10"
      >
        <motion.div
          animate={{ rotateY: [0, 360] }}
          transition={{
            duration: 3,
            delay: 1,
            repeat: Infinity,
            repeatDelay: 5,
          }}
          className="w-20 h-20 mb-4 relative"
        >
          <Image
            src="/logos/flexfit-logo.png"
            alt="FlexFit"
            width="80"
            height="80"
            className="object-contain"
            priority
          />
        </motion.div>
        <h1 className="text-3xl font-bold font-display text-foreground">
          FlexFit
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Your fitness journey starts here
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
        className="flex flex-col gap-4 max-w-sm mx-auto w-full relative z-10"
      >
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => "/onboarding"}
          className="flex items-center justify-center gap-3 w-full py-4 px-6 rounded-xl bg-foreground text-background font-semibold text-base"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z"
              fill="#4285F4"
            />
            <path
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              fill="#34A853"
            />
            <path
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              fill="#FBBC05"
            />
            <path
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              fill="#EA4335"
            />
          </svg>
          Continue with Google
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => router.push("/login")}
          className="flex items-center justify-center gap-3 w-full py-4 px-6 rounded-xl bg-secondary text-secondary-foreground font-semibold text-base border border-border"
        >
          <Mail size={20} />
          Continue with Email
        </motion.button>

        <div className="flex items-center gap-4 my-4">
          <motion.div
            className="flex-1 h-px bg-border"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            style={{ transformOrigin: "right" }}
          />
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="text-muted-foreground text-xs uppercase tracking-wider"
          >
            new here?
          </motion.span>
          <motion.div
            className="flex-1 h-px bg-border"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            style={{ transformOrigin: "left" }}
          />
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={() => router.push("/signup")}
          className="w-full py-4 px-6 rounded-xl bg-primary text-primary-foreground font-semibold text-base glow-primary-intense"
        >
          Create an Account
        </motion.button>
      </motion.div>
    </>
  );
}
